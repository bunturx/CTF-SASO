use Acme::Pony;
                        b                                                          
                      uffYB                                                        
                     UffYbuF                                                       
                    FYbUffYbUFf                                                    
                    yBUFfYBuffYbUF                                                 
                   FybuffyBuffYbufFy                                               
                  buffyBuFfYbuffYBuFFy                                             
                 bUFFyBUffYBUfFYBuFFYbUF                                           
                FYbUFfyBufFYBuffYbuFFybU                                           
                fFYBuffybufFybuFfybUffYBu                                          
               FFYbufFyBuffyBuFFyBUfFybUF                                          
              FYbuffybUffybUffYbufFYBuFFyB                                         
             uFfYBUfFyBUfFYbUfFybUFfyBufFY                                         
              BuFFYBuFFybuffyBufFyBUFFybuf                                         
                   fybUffybUFFYbuFFybUfFyb                                         
                    uFfYbUffyBuffYbUffYbuF                                         
                   fyBUFfyBufFYBUFfyBUfFYB                         uf              
                   fYbUffybuFfYbuffYbuFfYBu                      fFYbuFF           
                  ybuffyBuffybUfFybufFybUffy                    BUFfYBuFfY         
                 bUFFyBuFFyBUfFyBufFYbuFfyBUFfYBU               FfYBuFfYBU         
       Ffy      bUFFYBUffybufFybUFFYbUffYBufFYbuFFybUFfybuFfYBuffyBuFFybUFF        
     YbUffYb    uFfYbuFFyBUFFybUfFybufFybUffybuffyBUFfyBufFYBuFfyBuFFybUFFy        
    BUffyBuFFYbuffybUffyBuffYbufFybufFyBufFyBUfFyBufFYbuFFYbUFfybuffYbuffyBu       
   fFyBuF  fyBUfFYbufFYbuffYbUFfYBUFfYBuffYBuFfybuffyBufFyBufFYbUFfyBUFfybUfF      
  YBuFfy     buFFybuffyBufFyBufFYbUFfyBUFfybuffYbuffYbUFFyBuFfYBUffybufFybuFFy     
 bUFfyb        UFfYBuFfybuFFyBUFfyBUffYbUFFybuffybUffyBufFyBuFFyBuFFybufFYBUffY    
  buffYb        uFfyBuFfYbufFYbuFfyBUFfybuFfYbUfFybuFfYbuFFyBuFfyBUFfyBuffybUfF    
    yBUFFyb         UfFYbUfFYbuffYBUFfybufFYBuffYbuFFybufFybUffYbuFfYbUFfyBUFfyB   
     uFFyBu             fFYbUfFybUffybUffYBuFFYbuFfybUFfyBUFfYBuFFyBuFFyBuFFYBuff  
                          ybufFybufFYBuFfyBUFfYBufFybuFfybUfFybufFyBUFFYbUfFybUFf  
                            ybUFfYBu        FFybUFFyBuFfyBUfFYbUFFYbuFfYbuffybufF  
                            YBufFyb                 UFFyBufFyBUffYBUfFYbufFyBUFfyb 
                            uffYbuf                    FybuFfyBuFfybUffYbuFfYbuFfy 
                            BuFfYBU                     FfyBufFybUfF  ybUfFYBuffyb 
                            ufFybu                        ffyBuFfYbu   ffyBuFFybUf 
                            FyBUff                          YbUfFYBuF  fYbUFFYbuFf 
                            yBufFy                         BuffYbufFyb  uffyBufFyb 
                            UffYbu                      FFYbu   FfYBuf  fyBuFFYBuf 
                            FybUf                       fYbU    ffYbuF   fYbUfFyb  
                            uFfYB                      uffyBu    ffYb    UfFyBuf   
                             fybU                       ffy      BUFf     YbuFFY   
                            bUFf                                 yBuf      fYbu    
                          FFyBUF                                 fybU              
                         fFybuf                                 FyBUF              
                                                               FYbu                
                                                              FfYb                 


uffyBuFfybufFyBuffyBUFFYbUfFYBUFfYbUfFybuFfyBUFfyBuffYbufFyBUFFYbUfFYBUFfYb
